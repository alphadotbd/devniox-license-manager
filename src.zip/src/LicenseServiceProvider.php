<?php

namespace Devniox\LicenseManager;

use Illuminate\Support\ServiceProvider;

class LicenseServiceProvider extends ServiceProvider
{
    public function boot()
    {
        // code for license up/down check
        // Optional: add route, command, config publish etc.
    }

    public function register()
    {
        //
    }
}
